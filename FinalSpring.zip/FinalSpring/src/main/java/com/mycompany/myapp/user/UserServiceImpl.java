package com.mycompany.myapp.user;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<Map<String, Object>> select() {
		
		return userRepository.select();
	}

	@Override
	public Map<String, Object> detail(String uno) {
		
		return userRepository.detail(uno);
	}

	@Override
	public void create(Map<String, Object> map) {
		
		userRepository.create(map);
	}
	
	
	@Override
	public void delete(String uno) {
		
		userRepository.delete(uno);
	}
}
