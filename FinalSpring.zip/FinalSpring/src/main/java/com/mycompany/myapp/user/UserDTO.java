package com.mycompany.myapp.user;

import lombok.Data;

@Data
public class UserDTO {
	
	private String uno, uname, uaddr, uphone;
	
	
	

}
