package com.mycompany.myapp.user;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
	
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/read")
	public String read(Model model) {
		
		List<Map<String, Object>> list = userService.select();
		
		model.addAttribute("Lists", list); 	// "lists"라는 이름으로 list를 전달
		
		return "read";
	}
	
	
	@GetMapping("/detail/{uno}")				// 지울 uno를 url로 받기 위해서 {uno} 사용
	public String detail(@PathVariable String uno, Model model) {
		
		Map<String, Object> map = userService.detail(uno);
		
		model.addAttribute("user", map);
		
		return "detail";
	}
	
	
	
	@PostMapping("/create")
	public String create(@RequestParam Map<String, Object> map) {
		
		userService.create(map);
		
		return "redirect:/read";
	}
	
	
	
	@GetMapping("/create")
	public String create() {
		
		return "create";
	}
	
	
	
	@GetMapping("/delete/{uno}")				// 지울 uno를 url로 받기 위해서 {uno} 사용
	public String delete(@PathVariable String uno) {
		
		userService.delete(uno);
		
		return "redirect:/read";
	}
	
	

}
