package com.mycompany.myapp.user;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepositoryImpl implements UserRepository {
	
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	
	@Override
	public List<Map<String, Object>> select() {
		
		return sqlSessionTemplate.selectList("user.select");
	}

	@Override
	public Map<String, Object> detail(String uno) {
		
		return sqlSessionTemplate.selectOne("user.detail", uno);
	}

	@Override
	public void create(Map<String, Object> map) {
		sqlSessionTemplate.insert("user.insert", map);
		
	}
	
	
	@Override
	public void delete(String uno) {
		sqlSessionTemplate.delete("user.delete", uno);
		
	}

	

}
