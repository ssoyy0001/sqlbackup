package com.mycompany.myapp.user;

import java.util.List;
import java.util.Map;

public interface UserService {

	List<Map<String, Object>> select();
	
	Map<String, Object> detail(String uno);
	
	void create(Map<String, Object> map);
	
	void delete(String uno);
	
	
}
