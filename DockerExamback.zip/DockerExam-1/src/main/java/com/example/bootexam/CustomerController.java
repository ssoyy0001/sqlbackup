package com.example.bootexam;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/read")
	public String read(Model model) {
		
		model.addAttribute("Customers", customerService.read());
		
		return "read";
	}
	
	@GetMapping("/create")				// 입력폼 띄워주고
	public String create() {
		return "create";
	}
	
	@PostMapping("/create")				// 폼으로 입력받은 값 받기
	public String create(@RequestParam Map<String, Object> map) {
	
		this.customerService.create(map);
		
		return "redirect:/read";
	}
	
	
	
	@GetMapping("/delete")				// 폼으로 입력받은 값 받기
	public String delete(@RequestParam Map<String, Object> map) {
	
		this.customerService.delete(map);
		
		return "redirect:/read";
	}
	
	
	
	@GetMapping("/update")				// 입력폼 띄워주고
	public String update(@RequestParam Map<String, Object> map, Model model) {
		System.out.println(map.get("cid"));	//오류확인
		model.addAttribute("customer", customerService.detail(map));
		
		
		return "update";
	}
	
	
	@PostMapping("/update")				// 폼으로 입력받은 값 받기
	public String update(@RequestParam Map<String, Object> map) {
	
		this.customerService.create(map);
		
		return "redirect:/read";
	}
	
	
	
}
