package com.example.bootexam;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

@Primary
@Repository
public class CustomerRepositoryMBImpl implements CustomerRepository {

	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<Customer> read() {
		List<Customer> list = sqlSessionTemplate.selectList("temp.read");
		return list;
	}

	@Override
	public void create(Map<String, Object> map) {
		sqlSessionTemplate.insert("temp.insert",map);

	}
	
	@Override
	public void update(Map<String, Object> map) {
		sqlSessionTemplate.update("temp.update", map);
	}

	@Override
	public void delete(Map<String, Object> map) {
		sqlSessionTemplate.delete("temp.delete", map);
	}

	@Override
	public Customer detail(Map<String, Object> map) {
		System.out.println("repository : " +map.get("cid"));	//오류확인

		return sqlSessionTemplate.selectOne("temp.detail", map);
	}

}