package com.example.bootexam;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerRepository;
	
	//read
	@Override
	public List<Customer> read() {
		return this.customerRepository.read();
	}

	//create
	@Override
	public void create(Map<String, Object> map) {
		this.customerRepository.create(map);
		
	}

	// delete
	@Override
	public void delete(Map<String, Object> map) {
		this.customerRepository.delete(map);
		
	}

	@Override
	public void update(Map<String, Object> map) {
		this.customerRepository.update(map);
		
	}

	@Override
	public Customer detail(Map<String, Object> map) {	// map: 그 사람의 넘버
		System.out.println("service : " +map.get("cid"));	//오류확인

		return this.customerRepository.detail(map);
		
	}


}
