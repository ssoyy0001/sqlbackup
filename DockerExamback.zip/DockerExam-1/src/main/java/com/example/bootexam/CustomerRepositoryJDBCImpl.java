package com.example.bootexam;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerRepositoryJDBCImpl implements CustomerRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Customer> read() {

		String sql = "SELECT * FROM customer";
		List<Customer> list = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Customer>(Customer.class));

		return list;

	}

	// create
	@Override
	public void create(Map<String, Object> map) {

		String sql = "INSERT INTO customer (cid, cname) VALUES (?,?)";

		jdbcTemplate.update(sql, map.get("cid"), map.get("cname"));
		System.out.println("삽입 성공"); // 확인용

	}

	// delete
	@Override
	public void delete(Map<String, Object> map) {
		
		String sql = "DELETE FROM customer WHERE cid =?";

		jdbcTemplate.update(sql, map.get("id"));
		System.out.println("삭제 성공"); // 확인용

	}

	//에러 없애려고 일단 만듦
	@Override
	public void update(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}

	//에러 없애려고 일단 만듦
	@Override
	public Customer detail(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return null;
	}

}
