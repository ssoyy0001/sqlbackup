package com.example.bootexam;

public class Customer {

	public String cno, cid, cname, cdate;
	
	public Customer() {}

	public Customer(String cno, String cid, String cname, String cdate) {
		super();
		this.cno = cno;
		this.cid = cid;
		this.cname = cname;
		this.cdate = cdate;
	}

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCdate() {
		return cdate;
	}

	public void setCdate(String cdate) {
		this.cdate = cdate;
	}
	
	
	
}
