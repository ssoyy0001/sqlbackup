package com.example.bootexam;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

public interface CustomerRepository {

	public List<Customer> read();
	
	void create(Map<String, Object> map);
	
	void delete(Map<String, Object> map);

	void update(Map<String, Object> map);
		
	Customer detail(Map<String, Object> map);
	
}
